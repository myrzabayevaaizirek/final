// MatrixOperations.cs
using System;
using System.Threading.Tasks;

public static class MatrixOperations
{
    public static Matrix Transpose(Matrix matrix)
    {
        return matrix.Transpose();
    }

    public static Matrix ScalarMultiply(Matrix matrix, double scalar)
    {
        double[,] result = new double[matrix.Rows, matrix.Columns];
        for (int i = 0; i < matrix.Rows; i++)
        {
            for (int j = 0; j < matrix.Columns; j++)
            {
                result[i, j] = matrix[i, j] * scalar;
            }
        }
        return new Matrix(result);
    }

    public static Matrix Add(Matrix matrix1, Matrix matrix2)
    {
        if (matrix1.Rows != matrix2.Rows || matrix1.Columns != matrix2.Columns)
        {
            throw new ArgumentException("Matrices must have the same dimensions for addition.");
        }

        double[,] result = new double[matrix1.Rows, matrix1.Columns];
        for (int i = 0; i < matrix1.Rows; i++)
        {
            for (int j = 0; j < matrix1.Columns; j++)
            {
                result[i, j] = matrix1[i, j] + matrix2[i, j];
            }
        }
        return new Matrix(result);
    }

    public static Matrix Subtract(Matrix matrix1, Matrix matrix2)
    {
        if (matrix1.Rows != matrix2.Rows || matrix1.Columns != matrix2.Columns)
        {
            throw new ArgumentException("Matrices must have the same dimensions for subtraction.");
        }

        double[,] result = new double[matrix1.Rows, matrix1.Columns];
        for (int i = 0; i < matrix1.Rows; i++)
        {
            for (int j = 0; j < matrix1.Columns; j++)
            {
                result[i, j] = matrix1[i, j] - matrix2[i, j];
            }
        }
        return new Matrix(result);
    }

    public static async Task<Matrix> MultiplyAsync(Matrix matrix1, Matrix matrix2)
    {
        if (matrix1.Columns != matrix2.Rows)
        {
            throw new ArgumentException("Number of columns of the first matrix must be equal to the number of rows of the second matrix.");
        }

        Matrix result = new Matrix(new double[matrix1.Rows, matrix2.Columns]);
        await Task.Run(() =>
        {
            Parallel.For(0, matrix1.Rows, i =>
            {
                for (int j = 0; j < matrix2.Columns; j++)
                {
                    double sum = 0;
                    for (int k = 0; k < matrix1.Columns; k++)
                    {
                        sum += matrix1[i, k] * matrix2[k, j];
                    }
                    result[i, j] = sum;
                }
            });
        });

        return result;
    }
}
