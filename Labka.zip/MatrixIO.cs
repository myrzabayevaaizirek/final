// MatrixIO.cs
using System;
using System.IO;
using System.Threading.Tasks;

public static class MatrixIO
{
    public static async Task WriteMatrixAsync(Matrix matrix, Stream stream)
    {
        using (StreamWriter writer = new StreamWriter(stream))
        {
            await writer.WriteLineAsync($"{matrix.Rows} {matrix.Columns}");
            for (int i = 0; i < matrix.Rows; i++)
            {
                for (int j = 0; j < matrix.Columns; j++)
                {
                    await writer.WriteAsync(matrix[i, j] + " ");
                }
                await writer.WriteLineAsync();
            }
        }
    }

    public static async Task<Matrix> ReadMatrixAsync(Stream stream)
    {
        Matrix matrix;
        using (StreamReader reader = new StreamReader(stream))
        {
            string[] dimensions = (await reader.ReadLineAsync()).Split(' ');
            int rows = int.Parse(dimensions[0]);
            int columns = int.Parse(dimensions[1]);
            double[,] values = new double[rows, columns];
            for (int i = 0; i < rows; i++)
            {
                string[] rowValues = (await reader.ReadLineAsync()).Split(' ');
                for (int j = 0; j < columns; j++)
                {
                    values[i, j] = double.Parse(rowValues[j]);
                }
            }
            matrix = new Matrix(values);
        }
        return matrix;
    }

    public static void WriteMatrix(Matrix matrix, Stream stream)
    {
        using (StreamWriter writer = new StreamWriter(stream))
        {
            writer.WriteLine($"{matrix.Rows} {matrix.Columns}");
            for (int i = 0; i < matrix.Rows; i++)
            {
                for (int j = 0; j < matrix.Columns; j++)
                {
                    writer.Write(matrix[i, j] + " ");
                }
                writer.WriteLine();
            }
        }
    }

    public static Matrix ReadMatrix(Stream stream)
    {
        Matrix matrix;
        using (StreamReader reader = new StreamReader(stream))
        {
            string[] dimensions = reader.ReadLine().Split(' ');
            int rows = int.Parse(dimensions[0]);
            int columns = int.Parse(dimensions[1]);
            double[,] values = new double[rows, columns];
            for (int i = 0; i < rows; i++)
            {
                string[] rowValues = reader.ReadLine().Split(' ');
                for (int j = 0; j < columns; j++)
                {
                    values[i, j] = double.Parse(rowValues[j]);
                }
            }
            matrix = new Matrix(values);
        }
        return matrix;
    }
}
