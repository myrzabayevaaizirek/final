// Program.cs
using System;
using System.IO;
using System.Threading.Tasks;

public class Program
{
    public static async Task Main(string[] args)
    {
        int rows = 3;
        int columns = 3;
        Matrix randomMatrix = CreateRandomMatrix(rows, columns, 0, 10);
        Console.WriteLine(randomMatrix);

        Matrix transposedMatrix = MatrixOperations.Transpose(randomMatrix);
        Console.WriteLine(transposedMatrix);

        double scalar = 2.5;
        Matrix scaledMatrix = MatrixOperations.ScalarMultiply(randomMatrix, scalar);
        Console.WriteLine(scaledMatrix);

        Matrix matrix1 = CreateRandomMatrix(3, 2, 0, 10);
        Matrix matrix2 = CreateRandomMatrix(2, 3, 0, 10);
        Console.WriteLine(matrix1);
        Console.WriteLine(matrix2);

        Matrix productMatrix = await MatrixOperations.MultiplyAsync(matrix1, matrix2);
        Console.WriteLine(productMatrix);

        string filePath = "matrix.txt";
        using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
        {
            await MatrixIO.WriteMatrixAsync(randomMatrix, fileStream);
        }
        Console.WriteLine($"Matrix written to file: {filePath}");

        Matrix readMatrix;
        using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
        {
            readMatrix = await MatrixIO.ReadMatrixAsync(fileStream);
        }
        Console.WriteLine($"Matrix read from file: {filePath}");
        Console.WriteLine(readMatrix);
    }

    private static Matrix CreateRandomMatrix(int rows, int columns, int minValue, int maxValue)
    {
        Random random = new Random();
        double[,] values = new double[rows, columns];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                values[i, j] = random.NextDouble() * (maxValue - minValue) + minValue;
            }
        }
        return new Matrix(values);
    }
}
