// Matrix.cs
using System;

public class Matrix
{
    private double[,] values;

    public Matrix(double[,] values)
    {
        this.values = values;
    }

    public double this[int i, int j]
    {
        get { return values[i, j]; }
    }

    public int Rows => values.GetLength(0);
    public int Columns => values.GetLength(1);

    public Matrix Transpose()
    {
        double[,] result = new double[Columns, Rows];
        for (int i = 0; i < Rows; i++)
        {
            for (int j = 0; j < Columns; j++)
            {
                result[j, i] = values[i, j];
            }
        }
        return new Matrix(result);
    }

    public override string ToString()
    {
        string result = "";
        for (int i = 0; i < Rows; i++)
        {
            for (int j = 0; j < Columns; j++)
            {
                result += values[i, j] + " ";
            }
            result += "\n";
        }
        return result;
    }
}
