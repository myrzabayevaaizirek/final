using System.Windows.Forms;

namespace FileProcessorApp
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
        }
    }
}
