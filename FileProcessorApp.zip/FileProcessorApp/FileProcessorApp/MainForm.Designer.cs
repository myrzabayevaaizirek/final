namespace FileProcessorApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region ���, ������������� ��������� ������������� ���� Windows

        private void InitializeComponent()
        {
            menuStrip = new MenuStrip();
            aboutMenuItem = new ToolStripMenuItem();
            folderPathTextBox = new TextBox();
            selectFolderButton = new Button();
            foldersListBox = new ListBox();
            filesDataGridView = new DataGridView();
            processFilesButton = new Button();
            menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)filesDataGridView).BeginInit();
            SuspendLayout();

            menuStrip.ImageScalingSize = new Size(20, 20);
            menuStrip.Items.AddRange(new ToolStripItem[] { aboutMenuItem });
            menuStrip.Location = new Point(0, 0);
            menuStrip.Name = "menuStrip";
            menuStrip.Padding = new Padding(8, 3, 0, 3);
            menuStrip.Size = new Size(1067, 30);
            menuStrip.TabIndex = 0;
            menuStrip.Text = "menuStrip";
      
            aboutMenuItem.Name = "aboutMenuItem";
            aboutMenuItem.Size = new Size(118, 24);
            aboutMenuItem.Text = "� ���������";
            aboutMenuItem.Click += AboutMenuItem_Click;
        
            folderPathTextBox.Location = new Point(16, 62);
            folderPathTextBox.Margin = new Padding(4, 5, 4, 5);
            folderPathTextBox.Name = "folderPathTextBox";
            folderPathTextBox.ReadOnly = true;
            folderPathTextBox.Size = new Size(916, 27);
            folderPathTextBox.TabIndex = 1;
       
            selectFolderButton.Location = new Point(940, 58);
            selectFolderButton.Margin = new Padding(4, 5, 4, 5);
            selectFolderButton.Name = "selectFolderButton";
            selectFolderButton.Size = new Size(100, 35);
            selectFolderButton.TabIndex = 2;
            selectFolderButton.Text = "������� �����";
            selectFolderButton.UseVisualStyleBackColor = true;
            selectFolderButton.Click += SelectFolderButton_Click;
       
            foldersListBox.FormattingEnabled = true;
            foldersListBox.Location = new Point(16, 108);
            foldersListBox.Margin = new Padding(4, 5, 4, 5);
            foldersListBox.Name = "foldersListBox";
            foldersListBox.Size = new Size(265, 564);
            foldersListBox.TabIndex = 3;
            foldersListBox.DoubleClick += FoldersListBox_DoubleClick;
        
            filesDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            filesDataGridView.Location = new Point(293, 108);
            filesDataGridView.Margin = new Padding(4, 5, 4, 5);
            filesDataGridView.Name = "filesDataGridView";
            filesDataGridView.RowHeadersWidth = 51;
            filesDataGridView.Size = new Size(747, 566);
            filesDataGridView.TabIndex = 4;
            filesDataGridView.CellDoubleClick += FilesDataGridView_CellDoubleClick;
         
            processFilesButton.Location = new Point(827, 692);
            processFilesButton.Margin = new Padding(4, 5, 4, 5);
            processFilesButton.Name = "processFilesButton";
            processFilesButton.Size = new Size(213, 35);
            processFilesButton.TabIndex = 5;
            processFilesButton.Text = "��������� ��������� ������";
            processFilesButton.UseVisualStyleBackColor = true;
            processFilesButton.Click += ProcessFilesButton_Click;
         
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1067, 746);
            Controls.Add(processFilesButton);
            Controls.Add(filesDataGridView);
            Controls.Add(foldersListBox);
            Controls.Add(selectFolderButton);
            Controls.Add(folderPathTextBox);
            Controls.Add(menuStrip);
            MainMenuStrip = menuStrip;
            Margin = new Padding(4, 5, 4, 5);
            Name = "MainForm";
            Text = "File Processor App";
            menuStrip.ResumeLayout(false);
            menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)filesDataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem aboutMenuItem;
        private System.Windows.Forms.TextBox folderPathTextBox;
        private System.Windows.Forms.Button selectFolderButton;
        private System.Windows.Forms.ListBox foldersListBox;
        private System.Windows.Forms.DataGridView filesDataGridView;
        private System.Windows.Forms.Button processFilesButton;
    }
}
