using System;
using System.IO;
using System.Threading.Tasks;

namespace FileProcessorApp
{
    public class FileProcessor
    {
        public async Task<int> ProcessFileAsync(string filePath)
        {
            int delay = GenerateRandomDelay();
            await Task.Delay(delay);
            return delay;
        }

        private int GenerateRandomDelay()
        {
            Random random = new Random();
            return random.Next(1000, 5000);
        }
    }
}
